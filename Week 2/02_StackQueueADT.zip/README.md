# Lab 02: Stack and Queue ADT

See [PRELAB.md](PRELAB.md) for the prelab discussion and exercise.  
See [INLAB.md](INLAB.md) for the lab discussion and exercise.
