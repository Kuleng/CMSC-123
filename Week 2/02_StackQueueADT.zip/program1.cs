E
F
+ 3
+ 2
+ 1
+ 4
p
E
F
-
-
-
-
p
+ 1
+ 2
+ 3
p
C
p
Q
