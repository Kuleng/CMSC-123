// no need to include `list.h`
// since we are here to implement
// queue ADT

#include "queue.h"


QUEUE* createQueue(int maxLength){
	// since `QUEUE` is the same as the `LIST` structure
	// we can reuse the function `createList()` to create
	// a queue.
	return createList(maxLength);
}

// implement other functions here