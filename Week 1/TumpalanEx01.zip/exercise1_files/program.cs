E
+ i0 1
+ i1 2
+ i2 3
F
p
- i1
p
+ i1 2
p
- i2
p
- i0
p
C
p
Q
