#include "list.h"
#include <stdio.h>
// include other headers you need

// implement each function in list.h here

// routine for printing a list is given already.
void show(LIST *L){
	if(isEmpty(L)){
		printf("*empty*");
	}else{
		for(NODE* node = L->head; node != NULL; node=node->next){
			printf("%2d", node->value);
		}
	}
}